/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.catalina;


import java.beans.PropertyChangeListener;
import java.io.IOException;


/**
 * A <b>Store</b> is the abstraction of a Catalina component that provides persistent storage and loading of Sessions
 * and their associated user data. Implementations are free to save and load the Sessions to any media they wish, but it
 * is assumed that saved Sessions are persistent across server or context restarts.
 */
public interface Store {

    /**
     * @return the Manager instance associated with this Store.
     */
    Manager getManager();


    /**
     * Set the Manager associated with this Store.
     *
     * @param manager The Manager which will use this Store.
     */
    void setManager(Manager manager);


    /**
     * @return the number of Sessions present in this Store.
     *
     * @exception IOException if an input/output error occurs
     */
    int getSize() throws IOException;


    /**
     * Add a property change listener to this component.
     *
     * @param listener The listener to add
     */
    void addPropertyChangeListener(PropertyChangeListener listener);


    /**
     * @return an array containing the session identifiers of all Sessions currently saved in this Store. If there are
     *             no such Sessions, a zero-length array is returned.
     *
     * @exception IOException if an input/output error occurred
     */
    String[] keys() throws IOException;


    /**
     * Load and return the Session associated with the specified session identifier from this Store, without removing
     * it. If there is no such stored Session, return <code>null</code>.
     * <p>
     * Implementations should expect, and correctly handle, concurrent calls to any method but in particular calls to
     * {@code #load(String)}, {@code #save(Session)} and {@code #remove(String)} for the same session.
     * <p>
     * The session ID is user provided so stores must treat it as untrusted data.
     *
     * @param id Session identifier of the session to load
     *
     * @exception ClassNotFoundException if a deserialization error occurs
     * @exception IOException            if an input/output error occurs
     *
     * @return the loaded Session instance
     */
    Session load(String id) throws ClassNotFoundException, IOException;


    /**
     * Remove the Session with the specified session identifier from this Store, if present. If no such Session is
     * present, this method takes no action.
     * <p>
     * Implementations should expect, and correctly handle, concurrent calls to any method but in particular calls to
     * {@code #load(String)}, {@code #save(Session)} and {@code #remove(String)} for the same session.
     * <p>
     * The session ID is user provided so stores must treat it as untrusted data.
     *
     * @param id Session identifier of the Session to be removed
     *
     * @exception IOException if an input/output error occurs
     */
    void remove(String id) throws IOException;


    /**
     * Remove all Sessions from this Store.
     *
     * @exception IOException if an input/output error occurs
     */
    void clear() throws IOException;


    /**
     * Remove a property change listener from this component.
     *
     * @param listener The listener to remove
     */
    void removePropertyChangeListener(PropertyChangeListener listener);


    /**
     * Save the specified Session into this Store. Any previously saved information for the associated session
     * identifier is replaced.
     * <p>
     * Implementations should expect, and correctly handle, concurrent calls to any method but in particular calls to
     * {@code #load(String)}, {@code #save(Session)} and {@code #remove(String)} for the same session.
     *
     * @param session Session to be saved
     *
     * @exception IOException if an input/output error occurs
     */
    void save(Session session) throws IOException;
}
