package org.springframework.data.jpa.domain;

import jakarta.annotation.Generated;
import jakarta.persistence.metamodel.MappedSuperclassType;
import jakarta.persistence.metamodel.SingularAttribute;
import jakarta.persistence.metamodel.StaticMetamodel;
import java.util.Date;

@StaticMetamodel(AbstractAuditable.class)
@Generated("org.hibernate.processor.HibernateProcessor")
public abstract class AbstractAuditable_ extends org.springframework.data.jpa.domain.AbstractPersistable_ {

	public static final String CREATED_DATE = "createdDate";
	public static final String CREATED_BY = "createdBy";
	public static final String LAST_MODIFIED_DATE = "lastModifiedDate";
	public static final String LAST_MODIFIED_BY = "lastModifiedBy";

	
	/**
	 * @see org.springframework.data.jpa.domain.AbstractAuditable#createdDate
	 **/
	public static volatile SingularAttribute<AbstractAuditable, Date> createdDate;
	
	/**
	 * @see org.springframework.data.jpa.domain.AbstractAuditable#createdBy
	 **/
	public static volatile SingularAttribute<AbstractAuditable, Object> createdBy;
	
	/**
	 * @see org.springframework.data.jpa.domain.AbstractAuditable#lastModifiedDate
	 **/
	public static volatile SingularAttribute<AbstractAuditable, Date> lastModifiedDate;
	
	/**
	 * @see org.springframework.data.jpa.domain.AbstractAuditable#lastModifiedBy
	 **/
	public static volatile SingularAttribute<AbstractAuditable, Object> lastModifiedBy;
	
	/**
	 * @see org.springframework.data.jpa.domain.AbstractAuditable
	 **/
	public static volatile MappedSuperclassType<AbstractAuditable> class_;

}

